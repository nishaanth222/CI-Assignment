from visualize import  *

if __name__ == '__main__':
    run = visualize()
